// ============================================================
// Leitor IA — content script (isolated world), 3 papéis:
// 1. Gaveta: painel dentro da própria aba (iframe panel.html),
//    aberto/fechado pelo ícone da extensão (nada desenhado antes).
// 2. Leitura: fornece o DOM da página ao background
//    (leitor-ia-getpage) — funciona até sem scripting permission.
// 3. Web Bridge: automação DOM da interface oficial do provedor
//    (aba oculta): digitação compatível com ProseMirror/Lexical,
//    MutationObserver p/ streaming da resposta, detecção de
//    barreira de login/Cloudflare e snapshot p/ resume.
// config.js é injetado antes (content_scripts) → PROVIDERS/web.
// ============================================================
(() => {
  if (window.top !== window) return; // só no frame principal

  // ---------- mapa de seletores por host (vem do config.js) ----------
  const WEB = {};
  (typeof PROVIDERS !== "undefined" ? PROVIDERS : []).forEach((p) => {
    if (p.webUrl && p.web) {
      try {
        WEB[new URL(p.webUrl).host.replace(/^www\./, "")] = p.web;
      } catch (_) {}
    }
  });
  const GENERIC_ANSWERS = [
    "main article",
    'main [class*="markdown"]',
    'main [class*="prose"]',
    '[class*="message"] [class*="content"]',
    '[data-testid*="message"]',
    '[role="listitem"] article'
  ];

  const hostKey = () => location.host.replace(/^www\./, "");

  // ---------- gaveta do painel ----------
  let open = false;

  function ensureUI() {
    if (document.getElementById("leitor-ia-drawer")) return;
    const wrap = document.createElement("div");
    wrap.id = "leitor-ia-drawer";
    wrap.style.cssText =
      "position:fixed;top:0;right:0;height:100vh;width:min(420px,100vw);" +
      "z-index:2147483647;background:#f7f7f7;" +
      "box-shadow:-8px 0 32px rgba(0,0,0,.28);" +
      "transform:translateX(105%);transition:transform .25s ease;";
    const iframe = document.createElement("iframe");
    iframe.src = chrome.runtime.getURL("panel.html");
    iframe.title = "Leitor IA";
    iframe.style.cssText = "width:100%;height:100%;border:0;background:#f7f7f7;display:block;";
    wrap.appendChild(iframe);
    (document.documentElement || document.body).appendChild(wrap);
  }

  function toggle(force) {
    ensureUI();
    open = typeof force === "boolean" ? force : !open;
    const drawer = document.getElementById("leitor-ia-drawer");
    if (drawer) drawer.style.transform = open ? "translateX(0)" : "translateX(105%)";
  }

  // ---------- leitura da página (SPA-safe) ----------
  function extractLocalPage() {
    try {
      const selection = String(window.getSelection() || "").slice(0, 4000);
      let text = "";
      if (document.body) {
        // clone higienizado: não toca no DOM vivo (não quebra SPAs)
        const clone = document.body.cloneNode(true);
        // Só lixo visual: NUNCA remover form/input/button (telas de login).
        const drop = "script,style,noscript,template,svg,canvas,iframe,object,embed,video,audio";
        clone.querySelectorAll(drop).forEach((n) => n.remove());
        clone.querySelectorAll("input,textarea,select,button").forEach((el) => {
          const label =
            el.getAttribute("aria-label") ||
            el.getAttribute("placeholder") ||
            el.getAttribute("name") ||
            el.getAttribute("type") ||
            (el.tagName === "BUTTON" ? (el.textContent || "").trim() : "");
          const desc =
            "[" +
            el.tagName.toLowerCase() +
            (label ? ": " + String(label).replace(/\s+/g, " ").slice(0, 60) : "") +
            "]";
          el.replaceWith(document.createTextNode(" " + desc + " "));
        });
        text = (clone.innerText || clone.textContent || "")
          .replace(/\u00a0/g, " ")
          .replace(/[ \t]+\n/g, "\n")
          .replace(/\n{3,}/g, "\n\n")
          .trim();
      }
      const meta =
        (document.querySelector('meta[name="description"]') || {}).content ||
        (document.querySelector('meta[property="og:description"]') || {}).content ||
        "";
      return {
        ok: true,
        url: location.href,
        title: document.title || location.hostname,
        description: String(meta || ""),
        text: text.slice(0, 80000),
        selection: selection
      };
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  }

  // ---------- web bridge ----------
  function findComposer(cfg) {
    for (const s of cfg.composer || []) {
      const el = document.querySelector(s);
      if (el) return el;
    }
    return null;
  }

  // Digitação compatível com ProseMirror/Lexical/React:
  // focus → selectAll → insertText → InputEvent(inputType insertText).
  function fillAndSend(cfg, box, text) {
    box.focus();
    let ok = false;
    try {
      document.execCommand("selectAll", false, null);
      ok = document.execCommand("insertText", false, text);
    } catch (_) {}
    if (!ok) {
      box.textContent = text;
    }
    try {
      box.dispatchEvent(
        new InputEvent("input", { bubbles: true, cancelable: true, inputType: "insertText", data: text })
      );
    } catch (_) {
      box.dispatchEvent(new Event("input", { bubbles: true }));
    }
    setTimeout(() => {
      let btn = null;
      for (const s of cfg.send || []) {
        btn = document.querySelector(s);
        if (btn && !btn.disabled) break;
        btn = null;
      }
      if (btn) {
        btn.click();
      } else {
        ["keydown", "keypress", "keyup"].forEach((t) =>
          box.dispatchEvent(
            new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true })
          )
        );
      }
    }, 600);
  }

  // Barreira: login/Cloudflare/anti-bot impedindo o composer.
  function loginBarrier(cfg) {
    if (/\/(login|signin|auth|challenge)/i.test(location.pathname + location.search)) return true;
    return (cfg.login || []).some((s) => !!document.querySelector(s));
  }

  function lastAnswer(cfg, qSnippet) {
    const sels = (cfg.answer || []).concat(GENERIC_ANSWERS);
    for (const s of sels) {
      const all = document.querySelectorAll(s);
      if (all.length) {
        const el = all[all.length - 1];
        let t = "";
        try {
          // ignora blocos colapsáveis de "thinking" (Sonnet etc.)
          const c = el.cloneNode(true);
          c
            .querySelectorAll('details,[class*="thinking"],[data-testid*="thinking"]')
            .forEach((n) => n.remove());
          t = (c.innerText || "").trim();
        } catch (_) {
          t = (el.innerText || "").trim();
        }
        // ignora a nossa própria pergunta (bolha do usuário)
        if (t && !(qSnippet && t.includes(qSnippet))) return t;
      }
    }
    return "";
  }

  function isUiLine(s) {
    const t = (s || "").trim();
    if (!t) return true;
    if (t.length > 120) return false;
    return (
      /^(copy|copied|retry|try again|share|edit|delete|stop|👍||how was|response options|new chat|regenerate|rename|font|tokens?|words?|chars?)/i.test(
        t
      ) || t.length <= 8
    );
  }

  function cleanTail(raw) {
    const lines = String(raw || "").split("\n");
    while (lines.length && isUiLine(lines[lines.length - 1])) lines.pop();
    while (lines.length && isUiLine(lines[0])) lines.shift();
    return lines.join("\n").trim();
  }

  // Resposta: seletores; senão, tudo DEPOIS da pergunta no texto da página.
  function answerText(cfg, qSnippet) {
    const viaSel = lastAnswer(cfg, qSnippet);
    if (viaSel) return viaSel;
    const body = document.body ? document.body.innerText || "" : "";
    if (qSnippet && body.includes(qSnippet)) {
      return cleanTail(body.slice(body.lastIndexOf(qSnippet) + qSnippet.length));
    }
    return "";
  }

  function isGenerating(cfg) {
    return (cfg.stop || []).some((s) => !!document.querySelector(s));
  }

  // Indicadores de resposta COMPLETA (botão de copiar sob a bolha).
  const COPY_SELECTORS = [
    'button[aria-label*="Copy"]',
    'button[aria-label*="copy"]',
    'button[aria-label*="Copiar"]',
    '[data-testid*="copy"]',
    ".copy-button"
  ];
  function copyPresent() {
    return COPY_SELECTORS.some((s) => !!document.querySelector(s));
  }

  const post = (m) => {
    try {
      chrome.runtime.sendMessage(m);
    } catch (_) {}
  };

  // Estado p/ snapshot/resume (painel recarregado retoma o stream).
  const state = { reqId: null, text: "", done: false };

  // Watcher: MutationObserver (imune a timer throttling p/ deltas)
  // + interval de 1s p/ conclusão/timeout (aba oculta).
  function watchAnswer(cfg, qSnippet, reqId) {
    state.reqId = reqId || state.reqId;
    state.text = "";
    state.done = false;
    let mo = null;
    let safety = null;
    let stable = 0;
    let ticks = 0;
    let lastEval = 0;

    const finish = (t, error) => {
      if (state.done) return;
      state.done = true;
      state.text = t || state.text;
      if (mo) mo.disconnect();
      if (safety) clearInterval(safety);
      post({ type: "leitor-ia-web-done", reqId: state.reqId, text: state.text, error: error || null });
    };

    const evaluate = (force) => {
      const now = Date.now();
      if (!force && now - lastEval < 250) return; // throttle do MO
      lastEval = now;
      ticks++;
      const t = answerText(cfg, qSnippet);
      if (t && t !== state.text) {
        stable = 0;
        state.text = t;
        post({ type: "leitor-ia-web-delta", reqId: state.reqId, text: t });
      } else if (t) {
        stable++;
      }
      // Fim da resposta: sem indicador "gerando" E (botão copiar presente,
      // OU silêncio prolongado — limiar maior p/ respostas curtas, para não
      // cortar o stream durante pausas de thinking do modelo).
      // Enquanto o site mostra "gerando" (Stop visível), NUNCA conclui —
      // pausas de thinking não podem encerrar o stream.
      if (t && !isGenerating(cfg)) {
        if (copyPresent()) return finish(t);
        if (stable >= (t.length < 60 ? 20 : 8)) return finish(t);
      }
      if (t && ticks > 170) return finish(t);
      // Fail-safe: 20s sem nenhum delta = erro claro, nunca spinner eterno.
      if (!t && ticks > 20) {
        return finish(
          "",
          "Tempo limite esgotado ou modelo aguardando interação. Verifique a aba ou suas chaves."
        );
      }
    };

    try {
      mo = new MutationObserver(() => evaluate(false));
      mo.observe(document.body, { childList: true, subtree: true, characterData: true });
    } catch (_) {
      mo = null;
    }
    safety = setInterval(() => evaluate(true), 1000);
  }

  // ---------- mensagens ----------
  chrome.runtime.onMessage.addListener((m, _sender, sendResponse) => {
    if (m && m.type === "leitor-ia-toggle") {
      toggle();
      if (sendResponse) sendResponse({ ok: true });
    }
    if (m && m.type === "leitor-ia-getpage") {
      if (sendResponse) sendResponse(extractLocalPage());
    }
    if (m && m.type === "leitor-ia-snapshot") {
      if (sendResponse) sendResponse({ reqId: state.reqId, text: state.text, done: state.done });
    }
    if (m && m.type === "leitor-ia-ask") {
      const cfg = WEB[hostKey()];
      if (!cfg) {
        if (sendResponse) sendResponse({ ok: false, error: "Esta aba não é um site de modelo." });
        return;
      }
      const box = findComposer(cfg);
      if (!box) {
        if (sendResponse) {
          sendResponse({ ok: false, needLogin: true, reason: loginBarrier(cfg) ? "login" : "nocomposer" });
        }
        return;
      }
      fillAndSend(cfg, box, m.text || "");
      const qSnippet = String(m.text || "")
        .split("\n")[0]
        .trim()
        .slice(0, 120);
      watchAnswer(cfg, qSnippet, m.reqId);
      if (sendResponse) sendResponse({ ok: true });
    }
  });

  // Sem botão flutuante: o painel abre/fecha pelo ícone da extensão.
})();
